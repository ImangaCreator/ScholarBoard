import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { ScholarshipsProvider } from './lib/ScholarshipsContext.jsx';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <ScholarshipsProvider>
        <App />
      </ScholarshipsProvider>
    </BrowserRouter>
  </React.StrictMode>
);
